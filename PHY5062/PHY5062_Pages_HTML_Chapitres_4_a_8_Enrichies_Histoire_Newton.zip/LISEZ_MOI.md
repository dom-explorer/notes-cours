# PHY-5062-2 — Pages HTML interactives (chapitres 4 à 8)

## Installation
Copier tous les fichiers `.html` dans le même dossier de ton dépôt GitHub Pages, par exemple `PHY5062/`. L'adresse principale sera `PHY5062/index.html`. Les liens entre sections sont relatifs et fonctionnent sans modification. Les pages sont autonomes : elles intègrent leur CSS et leur JavaScript (aucun serveur requis pour les simulations).

## Contenu
- 15 pages de sections conformes aux intitulés ERPI–SOFAD;
- 3 exemples guidés par section, soit 45 exemples;
- 2 diagrammes dynamiques par section, soit 30 diagrammes;
- 5 missions autocorrigées par section, soit 75 questions;
- 3 défis avec solution développée par section (reprennent les exemples pour l'autonomie);
- des faits saillants, un contexte historique et des sources OpenStax par page.

## Technologie et limites
- Simulations dessinées avec l'API Canvas et JavaScript dans le navigateur; aucune installation de Java nécessaire.
- Graphiques et dessins schématiques (pas à l'échelle); lire les hypothèses du modèle.
- Les polices Google et les formules MathJax nécessitent un accès Internet. Les simulations Canvas sont autonomes après chargement de la page.
- Progression des missions sauvegardée localement quand le navigateur l'autorise.
- La plupart des leçons utilisent g = 9,81 m/s² dans leurs exemples; la simulation gravitationnelle utilise un modèle différent qui varie avec l'altitude.
- Ne pas importer ces HTML comme problèmes `.pg`: ce sont les pages de cours, complémentaires à la banque WeBWorK.

## Sources
- https://mstfgacspo.weebly.com/uploads/2/8/2/6/2826253/phy_5062-2_itineraire_erpi_sofad.pdf
- https://www.quebec.ca/education/formation-professionnelle-education-adultes/formation-generale-adultes/programmes-formation-generale-adultes/physique
- https://openstax.org/books/university-physics-volume-1/pages/1-introduction

## Notes pédagogiques
Le contenu est une adaptation originale pour la FGA; l'ordre des sections est repris du parcours ERPI–SOFAD. Vérifier les conventions particulières de tes cahiers et documents avant l'utilisation en classe.

## Édition enrichie — Histoire de la mécanique newtonienne
- Les **15 pages originales** ont été conservées, dont les graphiques Canvas, les exemples et les missions. Leur section historique est maintenant développée et une activité de méthode scientifique a été ajoutée à chacune.
- Une page complémentaire `PHY5062_Histoire_de_la_mecanique_newtonienne.html` retrace la progression des observations à la théorie et propose deux expériences interactives : billes sur un plan incliné (roulement idéal) et gravitation inversement proportionnelle au carré de la distance.
- L'accueil `index.html` est mis à jour pour rejoindre ce dossier historique.
- Historique : Galilée, Tycho Brahe, Kepler, Descartes, Newton, Halley, puis le développement du concept moderne d'énergie au XIXe siècle.
- Les sources utilisées dans les enrichissements sont citées avec des liens directs par section. Elles comprennent notamment The Newton Project (Oxford), Stanford Encyclopedia of Philosophy, la Cambridge University Library, la NASA, le Institute of Physics, Rice University et OpenStax University Physics volume 1.
- Les expériences de pensée et les exercices supplémentaires sont des adaptations pédagogiques originales. Aucune simulation n'est une reproduction fidèle d'un appareil historique.
- Les pages fonctionnent localement (simulations), mais MathJax et les polices nécessitent leur CDN pour être chargés.
